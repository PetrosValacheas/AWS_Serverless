import json


def aws_response(message, status_code):
    """
    Helper function to construct aws_responses
    """
    return {
        "body": json.dumps(message),
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
    }
